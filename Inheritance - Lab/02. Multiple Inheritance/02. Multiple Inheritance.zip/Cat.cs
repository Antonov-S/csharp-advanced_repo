﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02._Multiple_Inheritance
{
    class Cat : Animal
    {

        public void Meow()
        {
            Console.WriteLine("meowing…");
        }
    }
}
