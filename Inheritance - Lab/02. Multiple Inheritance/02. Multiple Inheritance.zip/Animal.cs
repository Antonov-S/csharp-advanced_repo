﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02._Multiple_Inheritance
{
    public class Animal
    {

        public void Eat()
        {
            Console.WriteLine("eating…");
        }
    }
}
