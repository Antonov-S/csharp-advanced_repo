﻿using System;
using System.Collections.Generic;
using System.Text;

namespace _02._Multiple_Inheritance
{
    public class Puppy : Dog
    {

        public void Weep()
        {
            Console.WriteLine("weeping…");
        }
    }
}
