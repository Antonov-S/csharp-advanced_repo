﻿namespace Zoo
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            Animal animal = new Bear("Meca");
            System.Console.WriteLine(animal);
        }
    }
}