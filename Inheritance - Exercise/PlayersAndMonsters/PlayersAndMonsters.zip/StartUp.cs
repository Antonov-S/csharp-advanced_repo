﻿namespace PlayersAndMonsters
{
    public class StartUp
    {
        public static void Main(string[] args)
        {
            DarkWizard darkWizard = new SoulMaster("Pesho", 17);
            System.Console.WriteLine(darkWizard);
        }
    }
}